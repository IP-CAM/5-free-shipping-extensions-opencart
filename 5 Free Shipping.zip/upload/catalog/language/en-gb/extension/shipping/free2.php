<?php
// Text
$_['text_title']       = 'free Shipping';
$_['text_description'] = 'free Shipping';